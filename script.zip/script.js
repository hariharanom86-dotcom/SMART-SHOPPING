﻿document.addEventListener("DOMContentLoaded", function () {

    // Notification Popup
    const notification = document.getElementById("notification-popup");
    const closeButton = document.getElementById("closeNotification");

    if (notification && closeButton) {
        closeButton.addEventListener("click", function () {
            notification.style.display = "none";
        });
    }

    // Shop Dropdown
    const shopToggle = document.getElementById("shopToggle");
    const dropdown = document.querySelector(".dropdown");

    if (shopToggle && dropdown) {
        dropdown.style.display = "none";

        shopToggle.addEventListener("click", function (event) {
            event.stopPropagation();

            dropdown.style.display =
                dropdown.style.display === "block" ? "none" : "block";
        });

        document.addEventListener("click", function (event) {
            if (!shopToggle.contains(event.target) &&
                !dropdown.contains(event.target)) {
                dropdown.style.display = "none";
            }
        });
    }

    // Product Elements
    const productGrid = document.querySelector(".product-grid");
    const products = Array.from(document.querySelectorAll(".product-card"));

    if (!productGrid || products.length === 0) return;

    const categoryFilters = document.querySelectorAll(".category-filter");
    const colourFilters = document.querySelectorAll(".colour-filter");
    const sizeFilters = document.querySelectorAll(".size-filter");

    const priceRange = document.getElementById("priceRange");
    const priceValue = document.getElementById("priceValue");

    const searchInput = document.getElementById("searchInput");
    const sortSelect = document.getElementById("sortSelect");

    const clearFilters = document.getElementById("clearFilters");

    const productCount = document.getElementById("productCount");
    const noProducts = document.getElementById("noProducts");

    const originalOrder = [...products];

    // Get Selected Filters
    function getSelectedValues(elements) {
        return Array.from(elements)
            .filter(element => element.checked)
            .map(element => element.value.toLowerCase());
    }

    // Apply Filters
    function applyFilters() {

        const selectedCategories = getSelectedValues(categoryFilters);
        const selectedColours = getSelectedValues(colourFilters);
        const selectedSizes = getSelectedValues(sizeFilters);

        const maxPrice = priceRange ? Number(priceRange.value) : Infinity;

        const searchText = searchInput
            ? searchInput.value.toLowerCase().trim()
            : "";

        let visibleProducts = [];

        products.forEach(product => {

            const category = (product.dataset.category || "").toLowerCase();
            const colour = (product.dataset.colour || "").toLowerCase();

            const sizes = (product.dataset.size || "")
                .toLowerCase()
                .split(",");

            const price = Number(product.dataset.price || 0);

            const productName = product.querySelector("h3")
                ? product.querySelector("h3").textContent.toLowerCase()
                : "";

            const categoryMatch =
                selectedCategories.length === 0 ||
                selectedCategories.includes(category);

            const colourMatch =
                selectedColours.length === 0 ||
                selectedColours.includes(colour);

            const sizeMatch =
                selectedSizes.length === 0 ||
                selectedSizes.some(size => sizes.includes(size));

            const priceMatch = price <= maxPrice;

            const searchMatch = productName.includes(searchText);

            const isVisible =
                categoryMatch &&
                colourMatch &&
                sizeMatch &&
                priceMatch &&
                searchMatch;

            product.style.display = isVisible ? "" : "none";

            if (isVisible) {
                visibleProducts.push(product);
            }
        });

        // Sorting
        const sortValue = sortSelect ? sortSelect.value : "default";

        if (sortValue === "low-high") {
            visibleProducts.sort((a, b) =>
                Number(a.dataset.price) - Number(b.dataset.price)
            );
        }

        else if (sortValue === "high-low") {
            visibleProducts.sort((a, b) =>
                Number(b.dataset.price) - Number(a.dataset.price)
            );
        }

        else if (sortValue === "name") {
            visibleProducts.sort((a, b) =>
                a.querySelector("h3").textContent.localeCompare(
                    b.querySelector("h3").textContent
                )
            );
        }

        else {
            visibleProducts.sort((a, b) =>
                originalOrder.indexOf(a) - originalOrder.indexOf(b)
            );
        }

        visibleProducts.forEach(product => {
            productGrid.appendChild(product);
        });

        // Product Count
        if (productCount) {
            productCount.textContent =
                `Showing ${visibleProducts.length} of ${products.length} Products`;
        }

        // No Products Found
        if (noProducts) {
            noProducts.style.display =
                visibleProducts.length === 0 ? "block" : "none";
        }
    }

    // Category Filter
    categoryFilters.forEach(filter => {
        filter.addEventListener("change", applyFilters);
    });

    // Colour Filter
    colourFilters.forEach(filter => {
        filter.addEventListener("change", applyFilters);
    });

    // Size Filter
    sizeFilters.forEach(filter => {
        filter.addEventListener("change", applyFilters);
    });

    // Price Filter
    if (priceRange) {
        if (priceValue) {
            priceValue.textContent = priceRange.value;
        }

        priceRange.addEventListener("input", function () {
            if (priceValue) {
                priceValue.textContent = priceRange.value;
            }

            applyFilters();
        });
    }

    // Search
    if (searchInput) {
        searchInput.addEventListener("input", applyFilters);
    }

    // Sorting
    if (sortSelect) {
        sortSelect.addEventListener("change", applyFilters);
    }

    // Clear All Filters
    if (clearFilters) {
        clearFilters.addEventListener("click", function () {

            categoryFilters.forEach(filter => filter.checked = false);
            colourFilters.forEach(filter => filter.checked = false);
            sizeFilters.forEach(filter => filter.checked = false);

            if (priceRange) {
                priceRange.value = priceRange.max;
            }

            if (priceValue && priceRange) {
                priceValue.textContent = priceRange.value;
            }

            if (searchInput) {
                searchInput.value = "";
            }

            if (sortSelect) {
                sortSelect.value = "default";
            }

            applyFilters();
        });
    }

    // Cart Counter
    const cartCount = document.getElementById("cartCount");
    let cartItems = 0;

    document.querySelectorAll(".add-to-cart").forEach(button => {

        button.addEventListener("click", function () {

            cartItems++;

            if (cartCount) {
                cartCount.textContent = cartItems;
            }

            const originalText = button.textContent;

            button.textContent = "Added!";
            
            setTimeout(() => {
                button.textContent = originalText;
            }, 1000);

        });

    });

    // Wishlist Counter
    const wishlistCount = document.getElementById("wishlistCount");
    let wishlistItems = 0;

    document.querySelectorAll(".wishlist-btn").forEach(button => {

        button.addEventListener("click", function () {

            const icon = button.querySelector("i");

            if (button.classList.contains("active")) {

                button.classList.remove("active");
                wishlistItems--;

                if (icon) {
                    icon.classList.remove("fa-solid");
                    icon.classList.add("fa-regular");
                }

            } else {

                button.classList.add("active");
                wishlistItems++;

                if (icon) {
                    icon.classList.remove("fa-regular");
                    icon.classList.add("fa-solid");
                }

            }

            if (wishlistCount) {
                wishlistCount.textContent = wishlistItems;
            }

        });

    });

    // Buy Now
    document.querySelectorAll(".buy-now").forEach(button => {

        button.addEventListener("click", function () {
            alert("Product selected! Order page integration is coming soon.");
        });

    });

    // Initial Filtering
    applyFilters();

});